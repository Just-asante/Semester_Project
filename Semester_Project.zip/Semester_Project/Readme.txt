NAME: JUSTICE ASANTE
INDEX NUMBER: UEB3264922
CLASS : IT B

PROJECT DESCRIPTION:

HOSPITAL MANAGEMENT SYSTEM

This C++ program implements a basic Hospital Management System that allows you to manage patient admissions, staff information, appointments, and medical records. The program provides a menu-based interface to perform various tasks within the hospital management system.The program also uses arrays to store data for patients, staff, appointments, and medical records, each with a maximum capacity of 100 entries.In addition,the program also uses random IDs for patients, staff, appointments, and medical records.

In summary it's features are

1. AUTHENTICATION:
The program prompts for a username and password to log in. Default credentials are provided,which are

 USERNAME - Justice
 PASSWORD -!@Password12345

2.PATIENT MANAGEMENT:
   a.Admit patients by providing their name, age, NHIS ID, reported time, and reported date.
   b.Display a list of admitted patients along with their details.


3.STAFF MANAGEMENT:
   a.Add staff members by specifying their name, age, specialization, and salary.
   b.Display a list of staff members along with their details.


4.APPOINTMENT MANAGEMENT:
  a.Add appointments by associating patients and doctors based on their respective IDs, along with appointment date and time.
  b.Display a list of appointments with their details.

5.MEDICAL RECORDS MANAGEMENT
  a.Add medical records by linking patients and doctors, providing date, time, and medical description.
  b.Display a list of medical records along with their details.